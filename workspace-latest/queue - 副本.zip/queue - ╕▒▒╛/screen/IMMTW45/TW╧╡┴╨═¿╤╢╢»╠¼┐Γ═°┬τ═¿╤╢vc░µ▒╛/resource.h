//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by commtest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COMMTEST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     136
#define IDB_BITMAP2                     143
#define IDB_BITMAP3                     144
#define IDC_DescIP                      1000
#define IDC_WIDTH                       1001
#define IDC_HEIGHT                      1002
#define IDC_DESCPORT                    1003
#define IDC_LOCALPORT                   1004
#define IDC_SENDDATA                    1005
#define IDC_PICNO                       1006
#define IDC_SHOWMODE                    1007
#define IDC_SHOWSPEED                   1008
#define IDC_SHOWTIME                    1009
#define IDC_OPENNET                     1010
#define IDC_DATASEND                    1011
#define IDC_RECEIVEDATA                 1012
#define IDC_CLOSENET                    1013
#define IDC_COLLIGATESENDDATA           1014
#define IDC_OPENSCREEN                  1015
#define IDC_CLOSESCREEN                 1016
#define IDC_SENDPIC                     1017
#define IDC_SENDPLAN                    1018
#define IDC_INTERCUT                    1019
#define IDC_TEXTLEFT                    1022
#define IDC_TEXTTOP                     1023
#define IDC_TEXTHEIGHT                  1024
#define IDC_TEXTWIDTH                   1025
#define IDC_FONTNAME                    1026
#define IDC_FONTSIZE                    1027
#define IDC_FONTCOLOR                   1029
#define IDC_INITIALIZE                  1030
#define IDC_GENEDATA                    1031
#define IDC_SENDGENEPIC                 1032
#define IDC_RELEASEPIC                  1033
#define IDC_TEXT                        1034
#define IDC_EDIT1                       1035
#define IDC_Wtite                       1036
#define IDC_Read                        1037
#define IDC_STATIC1                     1038
#define IDC_STATIC2                     1039
#define IDC_STATIC3                     1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
